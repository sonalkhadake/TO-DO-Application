import React from 'react';
import './styles.css';
import Todo from './components/Todo';



function App() {
  return (
     <div>
     <Todo/>
     </div>
    
  );
}

export default App;
